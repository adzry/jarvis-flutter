#!/bin/bash

# JARVIS Mobile Flutter - Installation Script
# This script helps you set up and run the Flutter app

echo "======================================"
echo "JARVIS Mobile Flutter v3.5.0"
echo "Installation & Deployment Script"
echo "======================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if Flutter is installed
echo -e "${BLUE}[1/6]${NC} Checking Flutter installation..."
if ! command -v flutter &> /dev/null; then
    echo -e "${RED}❌ Flutter is not installed!${NC}"
    echo "Please install Flutter from: https://flutter.dev/docs/get-started/install"
    exit 1
else
    echo -e "${GREEN}✅ Flutter is installed${NC}"
    flutter --version
fi

echo ""

# Check if in correct directory
echo -e "${BLUE}[2/6]${NC} Checking project structure..."
if [ ! -f "pubspec.yaml" ]; then
    echo -e "${RED}❌ Error: pubspec.yaml not found!${NC}"
    echo "Please run this script from the project root directory."
    exit 1
fi
echo -e "${GREEN}✅ Project structure verified${NC}"

echo ""

# Install dependencies
echo -e "${BLUE}[3/6]${NC} Installing dependencies..."
flutter pub get
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Dependencies installed successfully${NC}"
else
    echo -e "${RED}❌ Failed to install dependencies${NC}"
    exit 1
fi

echo ""

# Check for connected devices
echo -e "${BLUE}[4/6]${NC} Checking for connected devices..."
flutter devices
echo ""

# Ask user what to do
echo -e "${YELLOW}What would you like to do?${NC}"
echo "1) Run on connected device (debug mode)"
echo "2) Build release APK"
echo "3) Run tests"
echo "4) Clean project"
echo "5) Exit"
echo ""
read -p "Enter your choice (1-5): " choice

case $choice in
    1)
        echo ""
        echo -e "${BLUE}[5/6]${NC} Running app on connected device..."
        flutter run
        ;;
    2)
        echo ""
        echo -e "${BLUE}[5/6]${NC} Building release APK..."
        flutter build apk --release
        if [ $? -eq 0 ]; then
            echo ""
            echo -e "${GREEN}✅ APK built successfully!${NC}"
            echo -e "${GREEN}📦 Location: build/app/outputs/flutter-apk/app-release.apk${NC}"
        else
            echo -e "${RED}❌ Build failed${NC}"
        fi
        ;;
    3)
        echo ""
        echo -e "${BLUE}[5/6]${NC} Running tests..."
        flutter test
        ;;
    4)
        echo ""
        echo -e "${BLUE}[5/6]${NC} Cleaning project..."
        flutter clean
        echo -e "${GREEN}✅ Project cleaned${NC}"
        echo ""
        echo "Re-installing dependencies..."
        flutter pub get
        ;;
    5)
        echo "Exiting..."
        exit 0
        ;;
    *)
        echo -e "${RED}Invalid choice${NC}"
        exit 1
        ;;
esac

echo ""
echo -e "${GREEN}======================================"
echo "Done!"
echo "======================================${NC}"
