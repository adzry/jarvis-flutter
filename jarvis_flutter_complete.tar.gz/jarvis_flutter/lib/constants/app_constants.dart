import 'package:flutter/material.dart';

/// Premium Color Palette - Inspired by BoltUIX & Telegram
class AppColors {
  // Primary Colors
  static const Color primary = Color(0xFF0088CC);
  static const Color primaryDark = Color(0xFF006699);
  static const Color primaryLight = Color(0xFF64B5F6);
  
  // Backgrounds
  static const Color background = Color(0xFFFFFFFF);
  static const Color backgroundDark = Color(0xFF0F0F0F);
  static const Color chatBackground = Color(0xFFE5DDD5);
  static const Color chatBackgroundDark = Color(0xFF1A1A1A);
  
  // Message Bubbles
  static const Color incomingBubble = Color(0xFFFFFFFF);
  static const Color outgoingBubble = Color(0xFFDCF8C6);
  static const Color incomingBubbleDark = Color(0xFF2B2B2B);
  static const Color outgoingBubbleDark = Color(0xFF005C4B);
  
  // Text Colors
  static const Color textPrimary = Color(0xFF000000);
  static const Color textSecondary = Color(0xFF8E8E93);
  static const Color textWhite = Color(0xFFFFFFFF);
  static const Color textDark = Color(0xFF1A1A1A);
  
  // Status Colors
  static const Color online = Color(0xFF4CAF50);
  static const Color offline = Color(0xFF9E9E9E);
  static const Color sending = Color(0xFFFFA726);
  static const Color sent = Color(0xFF4CAF50);
  static const Color error = Color(0xFFEF5350);
  
  // Accent Colors (BoltUIX Style)
  static const Color gold = Color(0xFFD4AF37);
  static const Color purple = Color(0xFF7C4DFF);
  static const Color pink = Color(0xFFE91E63);
  static const Color cyan = Color(0xFF00BCD4);
  
  // UI Elements
  static const Color border = Color(0xFFE0E0E0);
  static const Color borderDark = Color(0xFF3A3A3A);
  static const Color shadow = Color(0x1A000000);
  static const Color divider = Color(0xFFEEEEEE);
}

/// Typography System
class AppTextStyles {
  // Headers
  static const TextStyle h1 = TextStyle(
    fontSize: 32,
    fontWeight: FontWeight.bold,
    height: 1.2,
  );
  
  static const TextStyle h2 = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.bold,
    height: 1.3,
  );
  
  static const TextStyle h3 = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.w600,
    height: 1.3,
  );
  
  // Body Text
  static const TextStyle bodyLarge = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.normal,
    height: 1.5,
  );
  
  static const TextStyle bodyMedium = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.normal,
    height: 1.4,
  );
  
  static const TextStyle bodySmall = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.normal,
    height: 1.3,
  );
  
  // Special
  static const TextStyle caption = TextStyle(
    fontSize: 11,
    fontWeight: FontWeight.w500,
    height: 1.2,
  );
  
  static const TextStyle button = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.5,
  );
}

/// App Constants
class AppConstants {
  static const String appName = 'JARVIS';
  static const String appVersion = '3.5.0';
  static const String baseUrl = 'http://192.168.43.37:3000';
  
  // Animation Durations
  static const Duration shortAnimation = Duration(milliseconds: 200);
  static const Duration mediumAnimation = Duration(milliseconds: 300);
  static const Duration longAnimation = Duration(milliseconds: 500);
  
  // Spacing
  static const double spacingXS = 4.0;
  static const double spacingS = 8.0;
  static const double spacingM = 16.0;
  static const double spacingL = 24.0;
  static const double spacingXL = 32.0;
  
  // Border Radius
  static const double radiusS = 8.0;
  static const double radiusM = 12.0;
  static const double radiusL = 16.0;
  static const double radiusXL = 24.0;
  static const double radiusCircle = 999.0;
  
  // Message Constraints
  static const int maxMessageLength = 5000;
  static const int maxMessagesInMemory = 100;
  static const double messageBubbleMaxWidth = 0.75;
}

/// App Theme
class AppTheme {
  static ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    colorScheme: ColorScheme.light(
      primary: AppColors.primary,
      secondary: AppColors.primaryLight,
      surface: AppColors.background,
      background: AppColors.background,
      error: AppColors.error,
    ),
    scaffoldBackgroundColor: AppColors.chatBackground,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.primary,
      foregroundColor: AppColors.textWhite,
      elevation: 0,
      centerTitle: false,
    ),
    textTheme: const TextTheme(
      displayLarge: AppTextStyles.h1,
      displayMedium: AppTextStyles.h2,
      displaySmall: AppTextStyles.h3,
      bodyLarge: AppTextStyles.bodyLarge,
      bodyMedium: AppTextStyles.bodyMedium,
      bodySmall: AppTextStyles.bodySmall,
    ),
  );
  
  static ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: ColorScheme.dark(
      primary: AppColors.primary,
      secondary: AppColors.primaryLight,
      surface: AppColors.backgroundDark,
      background: AppColors.backgroundDark,
      error: AppColors.error,
    ),
    scaffoldBackgroundColor: AppColors.chatBackgroundDark,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.primary,
      foregroundColor: AppColors.textWhite,
      elevation: 0,
      centerTitle: false,
    ),
  );
}
