import 'package:uuid/uuid.dart';

/// Message Status Enum
enum MessageStatus {
  sending,
  sent,
  delivered,
  read,
  error,
}

/// Message Sender Enum
enum MessageSender {
  user,
  jarvis,
  system,
}

/// Message Model
class Message {
  final String id;
  final String text;
  final MessageSender sender;
  final DateTime timestamp;
  final MessageStatus status;
  final String? imageUrl;
  final String? audioUrl;
  final Map<String, dynamic>? metadata;

  Message({
    String? id,
    required this.text,
    required this.sender,
    DateTime? timestamp,
    this.status = MessageStatus.sent,
    this.imageUrl,
    this.audioUrl,
    this.metadata,
  })  : id = id ?? const Uuid().v4(),
        timestamp = timestamp ?? DateTime.now();

  /// Check if message is from user
  bool get isUser => sender == MessageSender.user;

  /// Check if message is from Jarvis
  bool get isJarvis => sender == MessageSender.jarvis;

  /// Check if message has error
  bool get hasError => status == MessageStatus.error;

  /// Check if message is sending
  bool get isSending => status == MessageStatus.sending;

  /// Get formatted time (HH:mm)
  String get formattedTime {
    final hour = timestamp.hour.toString().padLeft(2, '0');
    final minute = timestamp.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  /// Get sender display name
  String get senderName {
    switch (sender) {
      case MessageSender.user:
        return 'YOU';
      case MessageSender.jarvis:
        return 'JARVIS';
      case MessageSender.system:
        return 'SYSTEM';
    }
  }

  /// Copy with method
  Message copyWith({
    String? id,
    String? text,
    MessageSender? sender,
    DateTime? timestamp,
    MessageStatus? status,
    String? imageUrl,
    String? audioUrl,
    Map<String, dynamic>? metadata,
  }) {
    return Message(
      id: id ?? this.id,
      text: text ?? this.text,
      sender: sender ?? this.sender,
      timestamp: timestamp ?? this.timestamp,
      status: status ?? this.status,
      imageUrl: imageUrl ?? this.imageUrl,
      audioUrl: audioUrl ?? this.audioUrl,
      metadata: metadata ?? this.metadata,
    );
  }

  /// Convert to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'text': text,
      'sender': sender.name,
      'timestamp': timestamp.toIso8601String(),
      'status': status.name,
      'imageUrl': imageUrl,
      'audioUrl': audioUrl,
      'metadata': metadata,
    };
  }

  /// Create from JSON
  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      id: json['id'],
      text: json['text'],
      sender: MessageSender.values.firstWhere(
        (e) => e.name == json['sender'],
        orElse: () => MessageSender.jarvis,
      ),
      timestamp: DateTime.parse(json['timestamp']),
      status: MessageStatus.values.firstWhere(
        (e) => e.name == json['status'],
        orElse: () => MessageStatus.sent,
      ),
      imageUrl: json['imageUrl'],
      audioUrl: json['audioUrl'],
      metadata: json['metadata'],
    );
  }
}

/// Conversation Model
class Conversation {
  final String id;
  final List<Message> messages;
  final DateTime createdAt;
  final DateTime updatedAt;
  final Map<String, dynamic>? metadata;

  Conversation({
    String? id,
    List<Message>? messages,
    DateTime? createdAt,
    DateTime? updatedAt,
    this.metadata,
  })  : id = id ?? const Uuid().v4(),
        messages = messages ?? [],
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  /// Get message count
  int get messageCount => messages.length;

  /// Get last message
  Message? get lastMessage => messages.isEmpty ? null : messages.last;

  /// Get last message text
  String get lastMessageText => lastMessage?.text ?? '';

  /// Add message
  Conversation addMessage(Message message) {
    return copyWith(
      messages: [...messages, message],
      updatedAt: DateTime.now(),
    );
  }

  /// Update message
  Conversation updateMessage(String messageId, Message updatedMessage) {
    final updatedMessages = messages.map((msg) {
      return msg.id == messageId ? updatedMessage : msg;
    }).toList();

    return copyWith(
      messages: updatedMessages,
      updatedAt: DateTime.now(),
    );
  }

  /// Remove message
  Conversation removeMessage(String messageId) {
    final updatedMessages = messages.where((msg) => msg.id != messageId).toList();
    return copyWith(
      messages: updatedMessages,
      updatedAt: DateTime.now(),
    );
  }

  /// Clear all messages
  Conversation clearMessages() {
    return copyWith(
      messages: [],
      updatedAt: DateTime.now(),
    );
  }

  /// Copy with method
  Conversation copyWith({
    String? id,
    List<Message>? messages,
    DateTime? createdAt,
    DateTime? updatedAt,
    Map<String, dynamic>? metadata,
  }) {
    return Conversation(
      id: id ?? this.id,
      messages: messages ?? this.messages,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      metadata: metadata ?? this.metadata,
    );
  }

  /// Convert to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'messages': messages.map((m) => m.toJson()).toList(),
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'metadata': metadata,
    };
  }

  /// Create from JSON
  factory Conversation.fromJson(Map<String, dynamic> json) {
    return Conversation(
      id: json['id'],
      messages: (json['messages'] as List)
          .map((m) => Message.fromJson(m))
          .toList(),
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt: DateTime.parse(json['updatedAt']),
      metadata: json['metadata'],
    );
  }
}
