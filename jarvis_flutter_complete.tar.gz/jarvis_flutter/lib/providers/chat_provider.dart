import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

import '../models/message.dart';
import '../services/api_service.dart';
import '../constants/app_constants.dart';

/// Chat Provider - Manages conversation state
class ChatProvider with ChangeNotifier {
  // Services
  final JarvisApiService _apiService = JarvisApiService();

  // State
  Conversation _conversation = Conversation();
  bool _isConnected = false;
  bool _isSending = false;
  bool _isTyping = false;
  String? _error;

  // Getters
  Conversation get conversation => _conversation;
  List<Message> get messages => _conversation.messages;
  bool get isConnected => _isConnected;
  bool get isSending => _isSending;
  bool get isTyping => _isTyping;
  String? get error => _error;
  bool get hasMessages => messages.isNotEmpty;

  /// Initialize
  Future<void> initialize() async {
    await _loadConversation();
    await checkConnection();
    
    // Add welcome message if conversation is empty
    if (messages.isEmpty) {
      _addMessage(Message(
        text: 'Welcome to JARVIS Mobile\n\nI\'m here to help you. What can I do for you today?',
        sender: MessageSender.jarvis,
      ));
    }
  }

  /// Check connection status
  Future<void> checkConnection() async {
    _isConnected = await _apiService.checkHealth();
    notifyListeners();
  }

  /// Send message
  Future<void> sendMessage(String text) async {
    if (text.trim().isEmpty || _isSending) return;

    // Create user message
    final userMessage = Message(
      text: text.trim(),
      sender: MessageSender.user,
      status: MessageStatus.sending,
    );

    // Add to conversation
    _addMessage(userMessage);
    _isSending = true;
    _error = null;
    notifyListeners();

    try {
      // Send to API
      final response = await _apiService.sendCommand(
        command: text.trim(),
        conversationId: _conversation.id,
      );

      // Update user message status
      _updateMessageStatus(userMessage.id, MessageStatus.sent);

      // Show typing indicator
      _isTyping = true;
      notifyListeners();

      // Simulate slight delay for better UX
      await Future.delayed(const Duration(milliseconds: 300));

      // Add Jarvis response
      if (response.success && response.output != null) {
        _addMessage(Message(
          text: response.output!,
          sender: MessageSender.jarvis,
        ));
      } else {
        _error = response.error ?? 'Unknown error occurred';
        _updateMessageStatus(userMessage.id, MessageStatus.error);
      }
    } catch (e) {
      _error = e.toString();
      _updateMessageStatus(userMessage.id, MessageStatus.error);
    } finally {
      _isSending = false;
      _isTyping = false;
      notifyListeners();
      await _saveConversation();
    }
  }

  /// Add message
  void _addMessage(Message message) {
    _conversation = _conversation.addMessage(message);
    notifyListeners();
  }

  /// Update message status
  void _updateMessageStatus(String messageId, MessageStatus status) {
    final message = messages.firstWhere((m) => m.id == messageId);
    final updatedMessage = message.copyWith(status: status);
    _conversation = _conversation.updateMessage(messageId, updatedMessage);
    notifyListeners();
  }

  /// Delete message
  void deleteMessage(String messageId) {
    _conversation = _conversation.removeMessage(messageId);
    notifyListeners();
    _saveConversation();
  }

  /// Clear conversation
  Future<void> clearConversation() async {
    _conversation = _conversation.clearMessages();
    
    // Add welcome message
    _addMessage(Message(
      text: 'Chat cleared. How can I help you?',
      sender: MessageSender.jarvis,
    ));
    
    notifyListeners();
    await _saveConversation();
    
    // Clear on server
    await _apiService.clearConversation(_conversation.id);
  }

  /// Save conversation to local storage
  Future<void> _saveConversation() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final json = jsonEncode(_conversation.toJson());
      await prefs.setString('conversation', json);
    } catch (e) {
      debugPrint('Error saving conversation: $e');
    }
  }

  /// Load conversation from local storage
  Future<void> _loadConversation() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final json = prefs.getString('conversation');
      
      if (json != null) {
        final data = jsonDecode(json);
        _conversation = Conversation.fromJson(data);
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Error loading conversation: $e');
    }
  }

  /// Export conversation
  String exportConversation() {
    final buffer = StringBuffer();
    buffer.writeln('JARVIS Conversation Export');
    buffer.writeln('Date: ${DateTime.now().toString()}');
    buffer.writeln('=' * 50);
    buffer.writeln();

    for (final message in messages) {
      buffer.writeln('[${message.formattedTime}] ${message.senderName}:');
      buffer.writeln(message.text);
      buffer.writeln();
    }

    return buffer.toString();
  }

  /// Get conversation statistics
  Map<String, dynamic> getStatistics() {
    final userMessages = messages.where((m) => m.isUser).length;
    final jarvisMessages = messages.where((m) => m.isJarvis).length;
    final avgMessageLength = messages.isEmpty
        ? 0
        : messages.map((m) => m.text.length).reduce((a, b) => a + b) ~/
            messages.length;

    return {
      'totalMessages': messages.length,
      'userMessages': userMessages,
      'jarvisMessages': jarvisMessages,
      'avgMessageLength': avgMessageLength,
      'conversationStart': _conversation.createdAt,
      'lastUpdate': _conversation.updatedAt,
    };
  }
}
