import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_constants.dart';
import '../models/message.dart';

/// API Response Model
class ApiResponse {
  final bool success;
  final String? output;
  final String? error;
  final String? provider;
  final Map<String, dynamic>? metadata;

  ApiResponse({
    required this.success,
    this.output,
    this.error,
    this.provider,
    this.metadata,
  });

  factory ApiResponse.fromJson(Map<String, dynamic> json) {
    return ApiResponse(
      success: json['success'] ?? false,
      output: json['output'],
      error: json['error'],
      provider: json['provider'],
      metadata: json['metadata'],
    );
  }
}

/// JARVIS API Service
class JarvisApiService {
  final String baseUrl;
  final Duration timeout;
  final int retryAttempts;

  JarvisApiService({
    this.baseUrl = AppConstants.baseUrl,
    this.timeout = const Duration(seconds: 30),
    this.retryAttempts = 3,
  });

  /// Send command to JARVIS
  Future<ApiResponse> sendCommand({
    required String command,
    String conversationId = 'mobile_default',
    String mode = 'standard',
  }) async {
    return _retryRequest(
      () => _sendCommandRequest(
        command: command,
        conversationId: conversationId,
        mode: mode,
      ),
    );
  }

  /// Internal send command request
  Future<ApiResponse> _sendCommandRequest({
    required String command,
    required String conversationId,
    required String mode,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/command'),
            headers: {
              'Content-Type': 'application/json',
            },
            body: jsonEncode({
              'command': command,
              'conversationId': conversationId,
              'mode': mode,
            }),
          )
          .timeout(timeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return ApiResponse.fromJson(data);
      } else {
        return ApiResponse(
          success: false,
          error: 'HTTP ${response.statusCode}: ${response.reasonPhrase}',
        );
      }
    } on TimeoutException {
      return ApiResponse(
        success: false,
        error: 'Request timeout. Please try again.',
      );
    } catch (e) {
      return ApiResponse(
        success: false,
        error: 'Network error: ${e.toString()}',
      );
    }
  }

  /// Check health status
  Future<bool> checkHealth() async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/health'))
          .timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['status'] == 'healthy';
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  /// Get conversation history
  Future<List<Message>?> getConversation(String conversationId) async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/conversation/$conversationId'))
          .timeout(timeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true && data['conversation'] != null) {
          final messages = (data['conversation']['messages'] as List)
              .map((m) => Message.fromJson(m))
              .toList();
          return messages;
        }
      }
      return null;
    } catch (e) {
      print('Error fetching conversation: $e');
      return null;
    }
  }

  /// Clear conversation
  Future<bool> clearConversation(String conversationId) async {
    try {
      final response = await http
          .delete(Uri.parse('$baseUrl/conversation/$conversationId'))
          .timeout(timeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['success'] == true;
      }
      return false;
    } catch (e) {
      print('Error clearing conversation: $e');
      return false;
    }
  }

  /// Retry logic wrapper
  Future<ApiResponse> _retryRequest(
    Future<ApiResponse> Function() request, [
    int attempt = 1,
  ]) async {
    try {
      final response = await request();

      // If successful or error is not network-related, return immediately
      if (response.success || attempt >= retryAttempts) {
        return response;
      }

      // Exponential backoff
      await Future.delayed(Duration(milliseconds: 500 * attempt));

      // Retry
      return _retryRequest(request, attempt + 1);
    } catch (e) {
      if (attempt >= retryAttempts) {
        return ApiResponse(
          success: false,
          error: 'Failed after $retryAttempts attempts: ${e.toString()}',
        );
      }

      // Exponential backoff
      await Future.delayed(Duration(milliseconds: 500 * attempt));

      // Retry
      return _retryRequest(request, attempt + 1);
    }
  }

  /// Stream response (for future streaming feature)
  Stream<String> streamResponse(String command) async* {
    // Future implementation for streaming responses
    // This will enable word-by-word display like ChatGPT
    yield* Stream.value(command);
  }
}
