import 'package:flutter/material.dart';
import '../constants/app_constants.dart';

/// Premium Chat Input Widget
class ChatInput extends StatefulWidget {
  final Function(String) onSend;
  final bool isEnabled;
  final VoidCallback? onVoicePress;
  final VoidCallback? onAttachPress;

  const ChatInput({
    Key? key,
    required this.onSend,
    this.isEnabled = true,
    this.onVoicePress,
    this.onAttachPress,
  }) : super(key: key);

  @override
  State<ChatInput> createState() => _ChatInputState();
}

class _ChatInputState extends State<ChatInput> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  bool _hasText = false;

  @override
  void initState() {
    super.initState();
    _controller.addListener(_onTextChanged);
  }

  @override
  void dispose() {
    _controller.removeListener(_onTextChanged);
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _onTextChanged() {
    final hasText = _controller.text.trim().isNotEmpty;
    if (hasText != _hasText) {
      setState(() {
        _hasText = hasText;
      });
    }
  }

  void _handleSend() {
    if (_hasText && widget.isEnabled) {
      widget.onSend(_controller.text.trim());
      _controller.clear();
      _focusNode.requestFocus();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppConstants.spacingM,
        vertical: AppConstants.spacingS,
      ),
      decoration: BoxDecoration(
        color: isDark ? AppColors.backgroundDark : AppColors.background,
        border: Border(
          top: BorderSide(
            color: isDark ? AppColors.borderDark : AppColors.border,
            width: 1,
          ),
        ),
      ),
      child: SafeArea(
        child: Row(
          children: [
            // Attach button (optional)
            if (widget.onAttachPress != null) ...[
              _buildIconButton(
                icon: Icons.add_circle_outline,
                onPressed: widget.onAttachPress,
                color: AppColors.textSecondary,
              ),
              const SizedBox(width: AppConstants.spacingS),
            ],

            // Input field
            Expanded(
              child: Container(
                constraints: const BoxConstraints(maxHeight: 120),
                decoration: BoxDecoration(
                  color: isDark
                      ? AppColors.incomingBubbleDark
                      : AppColors.background,
                  borderRadius: BorderRadius.circular(AppConstants.radiusXL),
                  border: Border.all(
                    color: isDark ? AppColors.borderDark : AppColors.border,
                    width: 1,
                  ),
                ),
                child: Row(
                  children: [
                    const SizedBox(width: 16),
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        focusNode: _focusNode,
                        enabled: widget.isEnabled,
                        maxLines: null,
                        maxLength: AppConstants.maxMessageLength,
                        textCapitalization: TextCapitalization.sentences,
                        style: AppTextStyles.bodyLarge,
                        decoration: InputDecoration(
                          hintText: 'Message...',
                          hintStyle: AppTextStyles.bodyLarge.copyWith(
                            color: AppColors.textSecondary,
                          ),
                          border: InputBorder.none,
                          counterText: '',
                          contentPadding: const EdgeInsets.symmetric(
                            vertical: 10,
                          ),
                        ),
                        onSubmitEditing: (value) => _handleSend(),
                      ),
                    ),
                    const SizedBox(width: 8),
                  ],
                ),
              ),
            ),

            const SizedBox(width: AppConstants.spacingS),

            // Send or Voice button
            AnimatedSwitcher(
              duration: AppConstants.shortAnimation,
              child: _hasText
                  ? _buildSendButton()
                  : widget.onVoicePress != null
                      ? _buildVoiceButton()
                      : _buildSendButton(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSendButton() {
    return Container(
      key: const ValueKey('send'),
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        color: _hasText && widget.isEnabled
            ? AppColors.primary
            : AppColors.textSecondary.withOpacity(0.3),
        shape: BoxShape.circle,
        boxShadow: _hasText && widget.isEnabled
            ? [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ]
            : null,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: _handleSend,
          customBorder: const CircleBorder(),
          child: const Center(
            child: Icon(
              Icons.send_rounded,
              color: AppColors.textWhite,
              size: 22,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildVoiceButton() {
    return Container(
      key: const ValueKey('voice'),
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.1),
        shape: BoxShape.circle,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: widget.onVoicePress,
          customBorder: const CircleBorder(),
          child: const Center(
            child: Icon(
              Icons.mic,
              color: AppColors.primary,
              size: 22,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildIconButton({
    required IconData icon,
    required VoidCallback? onPressed,
    required Color color,
  }) {
    return IconButton(
      icon: Icon(icon, color: color),
      onPressed: onPressed,
      splashRadius: 24,
    );
  }
}
