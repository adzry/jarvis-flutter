import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/message.dart';
import '../constants/app_constants.dart';

/// Premium Message Bubble - BoltUIX Inspired
class MessageBubble extends StatelessWidget {
  final Message message;
  final VoidCallback? onLongPress;
  final bool showAvatar;

  const MessageBubble({
    Key? key,
    required this.message,
    this.onLongPress,
    this.showAvatar = true,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isUser = message.isUser;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppConstants.spacingM,
        vertical: AppConstants.spacingXS,
      ),
      child: Row(
        mainAxisAlignment:
            isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Avatar for Jarvis messages
          if (!isUser && showAvatar) ...[
            _buildAvatar(),
            const SizedBox(width: AppConstants.spacingS),
          ],

          // Message bubble
          Flexible(
            child: GestureDetector(
              onLongPress: onLongPress,
              child: Container(
                constraints: BoxConstraints(
                  maxWidth: MediaQuery.of(context).size.width *
                      AppConstants.messageBubbleMaxWidth,
                ),
                decoration: BoxDecoration(
                  color: _getBubbleColor(isDark, isUser),
                  borderRadius: _getBorderRadius(isUser),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.shadow,
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Sender name (for Jarvis)
                    if (!isUser) ...[
                      Text(
                        message.senderName,
                        style: AppTextStyles.caption.copyWith(
                          color: AppColors.primary,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 4),
                    ],

                    // Message text
                    Text(
                      message.text,
                      style: AppTextStyles.bodyLarge.copyWith(
                        color: _getTextColor(isDark, isUser),
                        height: 1.4,
                      ),
                    ),

                    const SizedBox(height: 4),

                    // Footer (time + status)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          message.formattedTime,
                          style: AppTextStyles.caption.copyWith(
                            color: _getTimeColor(isDark, isUser),
                          ),
                        ),
                        if (isUser) ...[
                          const SizedBox(width: 4),
                          _buildStatusIcon(),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Spacing for user messages
          if (isUser && showAvatar)
            const SizedBox(width: AppConstants.spacingXL + 8),
        ],
      ),
    )
        .animate()
        .fadeIn(duration: AppConstants.shortAnimation)
        .slideY(
          begin: 0.1,
          end: 0,
          duration: AppConstants.shortAnimation,
          curve: Curves.easeOut,
        );
  }

  /// Build avatar
  Widget _buildAvatar() {
    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        color: AppColors.primary,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: const Center(
        child: Text(
          'J',
          style: TextStyle(
            color: AppColors.textWhite,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  /// Build status icon
  Widget _buildStatusIcon() {
    IconData icon;
    Color color;

    switch (message.status) {
      case MessageStatus.sending:
        icon = Icons.access_time;
        color = AppColors.sending;
        break;
      case MessageStatus.sent:
      case MessageStatus.delivered:
        icon = Icons.done_all;
        color = AppColors.sent;
        break;
      case MessageStatus.error:
        icon = Icons.error_outline;
        color = AppColors.error;
        break;
      default:
        icon = Icons.done;
        color = AppColors.sent;
    }

    return Icon(
      icon,
      size: 14,
      color: color,
    );
  }

  /// Get bubble color
  Color _getBubbleColor(bool isDark, bool isUser) {
    if (isDark) {
      return isUser
          ? AppColors.outgoingBubbleDark
          : AppColors.incomingBubbleDark;
    }
    return isUser ? AppColors.outgoingBubble : AppColors.incomingBubble;
  }

  /// Get text color
  Color _getTextColor(bool isDark, bool isUser) {
    if (isDark) {
      return AppColors.textWhite;
    }
    return AppColors.textPrimary;
  }

  /// Get time color
  Color _getTimeColor(bool isDark, bool isUser) {
    if (isDark) {
      return AppColors.textWhite.withOpacity(0.6);
    }
    return isUser
        ? const Color(0xFF5A8F7B)
        : AppColors.textSecondary;
  }

  /// Get border radius
  BorderRadius _getBorderRadius(bool isUser) {
    const radius = Radius.circular(AppConstants.radiusM);
    const sharpRadius = Radius.circular(4);

    if (isUser) {
      return const BorderRadius.only(
        topLeft: radius,
        topRight: radius,
        bottomLeft: radius,
        bottomRight: sharpRadius,
      );
    } else {
      return const BorderRadius.only(
        topLeft: sharpRadius,
        topRight: radius,
        bottomLeft: radius,
        bottomRight: radius,
      );
    }
  }
}

/// Typing Indicator Widget
class TypingIndicator extends StatefulWidget {
  const TypingIndicator({Key? key}) : super(key: key);

  @override
  State<TypingIndicator> createState() => _TypingIndicatorState();
}

class _TypingIndicatorState extends State<TypingIndicator>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppConstants.spacingM,
        vertical: AppConstants.spacingXS,
      ),
      child: Row(
        children: [
          _buildAvatar(),
          const SizedBox(width: AppConstants.spacingS),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 12,
            ),
            decoration: BoxDecoration(
              color: AppColors.incomingBubble,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(4),
                topRight: Radius.circular(AppConstants.radiusM),
                bottomLeft: Radius.circular(AppConstants.radiusM),
                bottomRight: Radius.circular(AppConstants.radiusM),
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.shadow,
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(3, (index) {
                return AnimatedBuilder(
                  animation: _controller,
                  builder: (context, child) {
                    final delay = index * 0.2;
                    final opacity = ((_controller.value + delay) % 1.0);
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: AppColors.textSecondary.withOpacity(opacity),
                        shape: BoxShape.circle,
                      ),
                    );
                  },
                );
              }),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAvatar() {
    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        color: AppColors.primary,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: const Center(
        child: Text(
          'J',
          style: TextStyle(
            color: AppColors.textWhite,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
